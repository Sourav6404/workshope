

const navLinks=document.getElementById("navLinks");
function OpenMenu(){
    navLinks.style.right="0"
}
function hideMenu(){
    navLinks.style.right="-200px";
}

